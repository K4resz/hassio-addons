#!/bin/bash
docker start t4re
docker ps -f name=t4re