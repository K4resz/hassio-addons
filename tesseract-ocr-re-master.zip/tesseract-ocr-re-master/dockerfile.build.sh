#!/bin/bash
docker build -t tesseractshadow/tesseract4re ./
docker images
